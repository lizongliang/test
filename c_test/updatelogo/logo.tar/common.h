/*************************************************************************
    > File Name: common.h
    > Author: zhaoxh
    > Mail: xinhai.zhao@163.com 
    > Created Time: Sat 31 Oct 2015 07:36:22 PM CST
 ************************************************************************/
#ifndef __COMMON_H
#define __COMMON_H

const char *pic_name = "boot0.bmp";
#endif

